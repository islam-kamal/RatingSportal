import 'package:flutter/material.dart';
import 'UI/Home.dart';
import 'UI/ReviewPage.dart';

void main(){
  runApp(
    new MaterialApp(
      title: 'Review',
      home: ReviewPage(),
      debugShowCheckedModeBanner: false,
    ),
  );
}