import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:reviewers/UI/ComplainOrReview.dart';

class Home extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _HomeState();
  }
}

class _HomeState extends State<Home> {
  final data = [
    ['images/vodafone.png', 'vodafone'],
    ['images/etisalat.png', 'Etisalat'],
    ['images/we.png', 'WE'],
    ['images/orange.png', 'orange'],
    ['images/atheep.png', 'Atheep'],
    ['images/telecom-egypt.png', 'Telecom'],
  ];
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(),
      body: StaggeredGridView.countBuilder(
        crossAxisCount: 2,
        padding: EdgeInsets.only(top: 10.0),
        itemCount: data.length,
        itemBuilder: (BuildContext context, int index) => GestureDetector(
          child: Card(
            margin: const EdgeInsets.all(10.0),
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  AspectRatio(
                    // use to make all cells of grid view in same size
                    aspectRatio: 18.0 / 13.0,
                    child: Image(
                      image: AssetImage(data[index][0]),
                      fit: BoxFit.fill,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(16.0, 12.0, 16.0, 8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(data[index][1], textAlign: TextAlign.center),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
          onTap: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => ComplainOrReview()));
          },
        ),
        staggeredTileBuilder: (int index) => StaggeredTile.fit(1),
      ),
    );
  }
}
