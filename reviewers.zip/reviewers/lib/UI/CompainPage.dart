import 'package:flutter/material.dart';
import 'package:reviewers/UI/ThanksMessage.dart';

class ComplainPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _ComplainPageState();
  }
}

class _ComplainPageState extends State<ComplainPage> {
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: new Container(
        alignment: Alignment.center,
        padding: EdgeInsets.only(left: 20.0,right: 20.0,),
        decoration: BoxDecoration(
            image: DecorationImage(
          image: AssetImage('images/world.png'),
          fit: BoxFit.cover,
        )),

        child: new SafeArea(
          child: SingleChildScrollView(
            child: Form(
               key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                textDirection: TextDirection.ltr,
                children: <Widget>[

                  Text(
                    'الأسم ',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.normal,
                      fontSize: 18.0,
                    ),

                  ),
                  new Container(
                    height: 50.0,
                    child: TextFormField(
                      style: TextStyle(color: Colors.white,),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0),
                          borderSide: const BorderSide(
                            color: Colors.white,
                            width: 1.0,
                          ),
                        ),
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter your name';
                        }
                        return null;
                      },
                    ),
                  ),
                  Text(
                    'البريد الالكترونى',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.normal,
                        fontSize: 18.0),
                  ),
                  new Container(
                    height: 50.0,
                    child: TextFormField(
                      keyboardType: TextInputType.emailAddress,
                      style: TextStyle(color: Colors.white,),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0),
                          borderSide: const BorderSide(
                            color: Colors.white,
                            width: 1.0,
                          ),
                        ),
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter email';
                        }
                        return null;
                      },
                    ),
                  ),
                  Text(
                    ' الموبايل  ',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.normal,
                        fontSize: 18.0),
                  ),
                  new Container(
                    height: 50.0,
                    child: TextFormField(
                      keyboardType: TextInputType.number,
                      style: TextStyle(color: Colors.white,),
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0),
                          borderSide: const BorderSide(
                            color: Colors.white,
                            width: 1.0,
                          ),
                        ),
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter phone';
                        }
                        return null;
                      },
                    ),
                  ),
                  Text(
                    '  التفاصيل  ',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.normal,
                        fontSize: 18.0),
                  ),
                  TextFormField(
                    style: TextStyle(color: Colors.white,),
                    textDirection: TextDirection.rtl,
                    keyboardType: TextInputType.multiline,
                    maxLines: 7,
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12.0),
                        borderSide: const BorderSide(
                          color: Colors.white,
                          width: 1.0,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter your message';
                      }
                      return null;
                    },
                  ),
                  // use Builder to solve Scaffold.of() called with a context that does not contain a Scaffold Exception
                  Builder(
                    builder: (ctx) => new Container(
                        padding: EdgeInsets.only(top: 25.0),
                        alignment: Alignment.center,
                        child: ButtonTheme(
                          minWidth: 150.0,
                          child: RaisedButton(
                            padding: const EdgeInsets.all(5.0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              side: BorderSide(
                                color: Colors.white,
                                width: 2.0,
                              ),
                            ),
                            color: Colors.black,
                            child: Text(
                              'ارسال',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18.0,
                              ),
                            ),

                          onPressed: () {
                            // Validate returns true if the form is valid, or false
                            // otherwise.
                            if (_formKey.currentState.validate()) {
                              // If the form is valid, write your code to send message
                              // If the form is valid, display a Snackbar.
                              Navigator.push(context, MaterialPageRoute(builder: (context)=>ThanksMessage()));
                            }
                          },
                          ),
                        )),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
