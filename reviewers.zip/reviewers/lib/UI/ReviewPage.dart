import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:reviewers/Assisant/RadioGroup.dart';
import 'package:reviewers/UI/ThanksMessage.dart';

class ReviewPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _ReviewPageState();
  }
}
class FruitsList {
  String name;
  int index;
  FruitsList({this.name, this.index});
}

class _ReviewPageState extends State<ReviewPage> {
  var questions = [
    'ما مدى رضائك عن منتج الشركة ؟',
    'ما مدى تقيمك لمستوى خدمة العملاء للشركة ؟',
    'ما مدى رضائك عن الدعاية المقدمة من الشركة',
    'ما مدى رضائك عن مستوى الخدمة داخل فروع الشركة '
  ];
  var questionTextField = new TextEditingController();
  var index ;
  var buttonText='التالى';
  var nextButton;

  @override
  void initState() {
    index=1;
  }

  //................. RadioGroup .........................
  // Default Radio Button Item
  String radioItem = null;
  // Group Value for Radio Button.
  int id = 1;
  List rateList=new List(); // collect all rate and used to detect acutally rate
  List<FruitsList> fList = [
    FruitsList(index: 1, name: "ممتاز",),
    FruitsList(index: 2, name: "جيد جدا",),
    FruitsList(index: 3, name: "جيد",),
    FruitsList(index: 4, name: "مقبول",),
    FruitsList(index: 5, name: "ضعيف",),
  ];
  //..........................................................
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(),
      body: new Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('images/world.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            SizedBox(
              height: 40.0,
            ),
            new TextField(
              controller: questionTextField,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
              ),
              decoration: InputDecoration(
                hintText: questions[0],
                hintStyle: TextStyle(
                  color: Colors.white,
                ),
                // to create border for TextField
                enabledBorder: const OutlineInputBorder(
                  borderSide: const BorderSide(
                    color: Color.fromRGBO(49, 103, 115, 5),
                    width: 3.0,
                  ),
                ),
              ),
              enabled: false,
            ),

            SizedBox(height: 40.0,),

            // radio group frame
           // RadioGroup(),
        new Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('images/world.png'),
              fit: BoxFit.cover,
            ),
          ),
          child: Column(
            children: <Widget>[

              Container(
                height: 290.0,
                width: 300.0,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20.0),
                  border: Border.all(
                    color: Colors.white,
                    width: 2.0,
                  ),
                ),
                child: Column(
                  children: fList
                      .map((data) =>
                      RadioListTile(
                        title: Text(
                          "${data.name}",
                          style: TextStyle(color: Colors.white),
                        ),
                        groupValue: id,
                        value: data.index,
                        activeColor: Colors.green,
                        onChanged: (val) {
                          setState(() {
                            radioItem = data.name;
                             rateList.add(radioItem); //use to add rate to list and then will send to thanksMessage page to inform user about rate
                            id = data.index;
                          });
                        },
                      ))
                      .toList(),
                ),
              ),
            ],
          ),
        ),



            SizedBox(height: 30.0,),



            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                SizedBox(
                  width: 50.0,
                ),
                new RaisedButton(
                  key: nextButton,
                  child: new Text(
                    buttonText,
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                  //use to make circle border for button
                  shape: new RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(2.0),
                    side: BorderSide(
                      color: Color.fromRGBO(49, 103, 115, 5),
                    ),
                  ),
                  color: Color.fromRGBO(49, 103, 115, 5),

                  onPressed: () {
                    setState(() {
                      questionTextField.text = questions[index];
                      if(radioItem.isEmpty){
                        //  should appear wrong mesage
                        Scaffold.of(context).showSnackBar(SnackBar(
                          content: Text("Choice one of these Options"),
                        ));
                      }
                      else{
                        index++;
                      }
                      if(index==questions.length){
                        buttonText='انهاء';

                        if(buttonText=='انهاء'){
                          setState(() {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>ThanksMessage(),
                                settings: RouteSettings(arguments: rateList)));
                          });
                        }
                      }
                    }
                    );
                  },
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
  void ratingResult(){
    rateList=ModalRoute.of(context).settings.arguments;
    for(var i=0;i<rateList.length;i++){
      print(rateList[i]);
    }
  }
}
