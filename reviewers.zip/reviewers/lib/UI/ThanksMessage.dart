import 'package:flutter/material.dart';

import 'Home.dart';

class ThanksMessage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _ThanksMessageState();
  }
}

class _ThanksMessageState extends State<ThanksMessage> {
   List rating;
  @override
  Widget build(BuildContext context) {
    return new Scaffold(

      appBar: AppBar(),
      body: new Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
            image: DecorationImage(
          image: AssetImage('images/world.png'),
          fit: BoxFit.cover,
        )),
        child: new Container(
            padding: EdgeInsets.only(top: 70.0),
            child: new Column(
              children: <Widget>[
                Image(
                  width: 400.0,
                  height: 200.0,
                  image: AssetImage('images/thanks.png'),
                ),
                new SizedBox(
                  height: 50.0,
                ),
                   new SizedBox(
                     width: 170,
                     child:  new RaisedButton(
                       child: new Text('End ',),
                       onPressed: () {
                         ratingResult;
                         Navigator.push(
                           context,
                           MaterialPageRoute(builder: (context) => Home()),
                         );
                       },
                     ),
                   )


              ],
            )),
      ),
    );
  }
  void ratingResult(){
    rating=ModalRoute.of(context).settings.arguments;
    for(var i=0;i<rating.length;i++){
      print(rating[i]);
    }
  }
}
